package com.luv2code.springdemo;

import org.springframework.stereotype.Component;

@Component("theSillyCoachStudent")
public class TennisCoachStudent implements Coach{
    @Override
    public String getDailyWorkout() {
        return "Comeon Student finish up your work";
    }

    @Override
    public String getDailyFortune() {
        return null;
    }
}
