package com.luv2code.springdemo;

public class TrackCoach implements Coach {
    //define a private field for the dependency
    private FortuneService fortuneService;

    public TrackCoach(FortuneService fortuneService) {
        this.fortuneService = fortuneService;
    }

    //define a constructor for dependency injection
    @Override
    public String getDailyWorkOut() {
        return "Run a hard 5k";
    }

    @Override
    public String CoachName(String coachName) {
        return coachName;
    }

    @Override
    public String getDailyFortune() {
        return "Just Do it " +fortuneService.getFortune();
    }

    // add an init method
    public void doMyStartupStuff()
    {
      System.out.println("TrackCoach: inside method doMyStartupStuff");
    }

    // add a destroy method
    public void doMyCleanStuffYoYo()
    {
        System.out.println("TrackCoach: inside method doMyCleanStuffYoYo");
    }

}
