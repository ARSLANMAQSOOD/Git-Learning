package com.luv2code.springdemo;

import java.util.Random;

public class HappyFortuneService implements FortuneService{
int[] array= {1, 2, 3};
    @Override
    public String getFortune() {
        return "Today is your lucky day";
    }

    @Override
    public int getFortune2() {
        Random r= new Random();
        int no= r.nextInt(array.length);
        return no;
    }
}
