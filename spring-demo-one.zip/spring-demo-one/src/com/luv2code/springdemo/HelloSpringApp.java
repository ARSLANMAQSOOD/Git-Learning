package com.luv2code.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSpringApp {


    public static void main(String[] args)
    {
        //load the spring configuration file
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        //retrieve bean from spring container
         Coach theCoach = context.getBean("myCoach",Coach.class);
        Coach the2Coach = context.getBean("my2Coach",Coach.class);
         // call methods on the bean
         System.out.println(theCoach.getDailyWorkOut()+"and the coach name is "+theCoach.CoachName("Samuel"));
         System.out.println(the2Coach.getDailyWorkOut()+"and the coach name is "+the2Coach.CoachName("Ozil"));

         //lets call out the method Fortune Service
        System.out.println(theCoach.getDailyFortune());
        System.out.println(the2Coach.getDailyFortune());
         // close the context
         context.close();
    }

}
