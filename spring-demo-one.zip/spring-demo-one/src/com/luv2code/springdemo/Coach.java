package com.luv2code.springdemo;

public interface Coach {
     public String getDailyWorkOut();
     public String CoachName(String coachName);
     public  String getDailyFortune();
}
