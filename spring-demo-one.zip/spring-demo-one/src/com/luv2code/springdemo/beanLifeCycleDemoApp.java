package com.luv2code.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class beanLifeCycleDemoApp {

    public static void main(String[] args)
    {
        //load the spring configuration file
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean-LifeCycle-applicationContext.xml");

        //retrieve bean from spring container
        Coach theCoach= context.getBean("myCoach",Coach.class);
        Coach theCoach2= context.getBean("my2Coach",Coach.class);

        System.out.println(theCoach.getDailyWorkOut());
        System.out.println(theCoach2.getDailyWorkOut());
        //close the context
        context.close();

    }
}
